import express from "express";
import bodyParser from "body-parser";
import pg from "pg";
const app = express();
const port = 3000;
const db=new pg.Client({
  user:"postgres",
  host:"localhost",
  database:"world",
  password:"Adi@0012",
  port:5432,
});


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

db.connect();
let countries=[];


app.get("/", async (req, res) => {
  //Write your code here.
  const result = await db.query("SELECT country_code FROM visited_countries");
  
      
    result.rows.forEach((country)=>{countries.push(country.country_code);});
    // let total=countries.length;
    console.log(countries);
      res.render("index.ejs",{countries:countries,total:countries.length});
      countries=[];

    
  });
  let countriesDB=[];
  db.query("SELECT country_name,country_code FROM countries",(err,res)=>{
    if (err) {
      console.error("Error executing query", err.stack);
    } else {
      countriesDB = res.rows;
    }
    
  });


app.post("/add",async(req,res)=>{
  

  let newV=req.body.country.trim();
  countriesDB.forEach((cn)=>{

if(cn.country_name.toLowerCase()===newV.toLowerCase()){
console.log(cn.country_code);
countries.push(cn.country_code);
};

  });
 // console.log(countriesDB);
 const result = await db.query("SELECT country_code FROM visited_countries");

result.rows.forEach((country) => {
    const countryCode = country.country_code;
    if (!countries.includes(countryCode)) {
        countries.push(countryCode);
    }
});

  // let total=countries.length;
  console.log(countries);
    res.render("index.ejs",{countries:countries,total:countries.length});

});


app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
